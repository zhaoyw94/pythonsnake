# -*- coding: utf-8 -*-

"""
Created on Fri Nov  14 17:30:34 2018

@author: Yiwen, Quan, Kristie, Huy
"""



from appJar import gui #imports the gui library from appJar


print("Yiwen, Quan, Kristie, Huy")

import random
import string
import tkinter
import time
import pandas

def press(btn):
    if btn == "Exit":
        app.stop()
    elif btn == "Dice Rolling Game":
        app.infoBox("b1","this is our first game, dice rolling")
       # this game will be created by Quan and Yiwen 
        def get_dice():
            return random.randint(1,6)
 
        def the_open(player_dice,computer_dice):
            print("Let's start playing Dice Rolling!")
            time.sleep(1)
            print('player:' + str(player_dice))
            time.sleep(1)
            print('CPU:' + str(computer_dice))
            time.sleep(1)
 
        def every_game(player_money,computer_money):
            print('Get Ready!!!')
            time.sleep(1)
            print('Go!')
            time.sleep(2)
            print("The Chip for both CPU and Player")
            print('Player：' + str(player_money))
            print('CPU:' + str(computer_money))
            time.sleep(2)
            print("Player's roll turn")
            time.sleep(1)
            player_dice = get_dice()
            print('Player dice is: ' + str(player_dice))
            time.sleep(2)
            print("CPU's roll turn")
            time.sleep(1)
            computer_dice = get_dice()
            print('CPU is done for rolling: ' + str(computer_dice))
            time.sleep(1)
            result = input('The player side bet first, whether bet or not？[y/n]')
            if result.lower() == 'y':
                while True:
                    player_bets = int(input('Select range：[1-{0}]'.format(player_money)))
                    if player_bets >= 1 and player_bets <= player_money:
                        break
                print('The player bet{0}'.format(player_bets))
                time.sleep(1)
                print("CPU is thinking")
                time.sleep(2)
                if random.choice('yn') == str('y'):
                    computer_bets = random.randint(1,computer_money)
                    print('CPU set bet{0}'.format(computer_bets))
                    time.sleep(1)
                    the_open(player_dice,computer_dice)
                    if player_dice > computer_dice:
                        print('player win and player get chip{0}'.format(computer_bets))
                        player_money += computer_bets
                        computer_money -= computer_bets
                    elif player_dice == computer_dice:
                        print('The draw! Both sides withdrew their chips')
                    else:
                        print('Computer games! The player loses the chip{0}'.format(player_bets))
                        player_money -= player_bets
                        computer_money += player_bets
                else:
                    print('CPU gives up, player gets back chip')
                    time.sleep(1)
                    the_open(player_dice,computer_dice)
            else:
                print('Player gives up')
                time.sleep(1)
                the_open(player_dice,computer_dice)
            return [player_money,computer_money]

        def play_game():
            print('Game Start!')
            player_money = 100
            computer_money = 100
            time.sleep(1)
            while player_money != 0 and computer_money != 0:
                money_list = every_game(player_money,computer_money)
                player_money = money_list[0]
                computer_money = money_list[1]
                if player_money == 0:
                    print('You Lose!')
                    app.stop()
                else:
                    print('You Win!')
 
        if __name__ == '__main__':
            play_game()

            
    elif btn == "Snake Game":
        app.infoBox("b1","this is our second game, Snake game")
       #this game will be created by Huy and Kristie 
        HEAD_CHARACTER = 'ö'
        FOOD_CHARACTERS = string.ascii_letters


        class Application:
            TITLE = 'Snake'
            SIZE = 300, 300

            def __init__(self, master):
                    self.master = master

                    self.head = None
                    self.head_position = None
                    self.segments = []
                    self.segment_positions = []
                    self.food = None
                    self.food_position = None
                    self.direction = None
                    self.moved = True

                    self.running = False
                    self.init()

            def init(self):
                    self.master.title(self.TITLE)

                    self.canvas = tkinter.Canvas(self.master)
                    self.canvas.grid(sticky=tkinter.NSEW)
                    
                    self.start_button = tkinter.Button(self.master, text='Start', command=self.on_start)
                    self.start_button.grid(sticky=tkinter.EW)

                    self.master.bind('w', self.on_up)
                    self.master.bind('a', self.on_left)
                    self.master.bind('s', self.on_down)
                    self.master.bind('d', self.on_right)

                    self.master.columnconfigure(0, weight=1)
                    self.master.rowconfigure(0, weight=1)
                    self.master.resizable(width=False, height=False)
                    self.master.geometry('%dx%d' % self.SIZE)

            def on_start(self):
                    self.reset()
                    if self.running:
                        self.running = False
                        self.start_button.configure(text='Start')
                    else:
                        self.running = True
                        self.start_button.configure(text='Stop')
                        self.start()

            def reset(self):
                    self.segments.clear()
                    self.segment_positions.clear()
                    self.canvas.delete(tkinter.ALL)

            def start(self):
                    width = self.canvas.winfo_width()
                    height = self.canvas.winfo_height()

                    self.canvas.create_rectangle(10, 10, width-10, height-10)
                    self.direction = random.choice('wasd')
                    head_position = [round(width // 2, -1), round(height // 2, -1)]
                    self.head = self.canvas.create_text(tuple(head_position), text=HEAD_CHARACTER)
                    self.head_position = head_position
                    self.spawn_food()
                    self.tick()

            def spawn_food(self):
                    width = self.canvas.winfo_width()
                    height = self.canvas.winfo_height()
                    positions = [tuple(self.head_position), self.food_position] + self.segment_positions
                    
                    position = (round(random.randint(20, width-20), -1), round(random.randint(20, height-20), -1))
                    while position in positions:
                        position = (round(random.randint(20, width-20), -1), round(random.randint(20, height-20), -1))

                    character = random.choice(FOOD_CHARACTERS)
                    self.food = self.canvas.create_text(position, text=character)
                    self.food_position = position
                    self.food_character = character

            def tick(self):
                    width = self.canvas.winfo_width()
                    height = self.canvas.winfo_height()
                    previous_head_position = tuple(self.head_position)

                    if self.direction == 'w':
                        self.head_position[1] -= 10
                    elif self.direction == 'a':
                        self.head_position[0] -= 10
                    elif self.direction == 's':
                        self.head_position[1] += 10
                    elif self.direction == 'd':
                        self.head_position[0] += 10

                    head_position = tuple(self.head_position)
                    if (self.head_position[0] < 10 or self.head_position[0] >= width-10 or
                        self.head_position[1] < 10 or self.head_position[1] >= height-10 or
                        any(segment_position == head_position for segment_position in self.segment_positions)):
                        self.game_over()
                        return

                    if head_position == self.food_position:
                        self.canvas.coords(self.food, previous_head_position)
                        self.segments.append(self.food)
                        self.segment_positions.append(previous_head_position)
                        self.spawn_food()

                    if self.segments:
                        previous_position = previous_head_position
                        for index, (segment, position) in enumerate(zip(self.segments, self.segment_positions)):
                            self.canvas.coords(segment, previous_position)
                            self.segment_positions[index] = previous_position
                            previous_position = position

                    self.canvas.coords(self.head, head_position)
                    self.moved = True

                    if self.running:
                        self.canvas.after(50, self.tick)

            def game_over(self):
                width = self.canvas.winfo_width()
                height = self.canvas.winfo_height()

                self.running = False
                self.start_button.configure(text='Start')
                score = len(self.segments) * 10
                self.canvas.create_text((round(width // 2, -1), round(height // 2, -1)), text='Game Over! Your score was: %d' % score)

            def on_up(self, event):
                if self.moved and not self.direction == 's':
                    self.direction = 'w'
                    self.moved = False

            def on_down(self, event):
                if self.moved and not self.direction == 'w':
                    self.direction = 's'
                    self.moved = False

            def on_left(self, event):
                if self.moved and not self.direction == 'd':
                    self.direction = 'a'
                    self.moved = False

            def on_right(self, event):
                if self.moved and not self.direction == 'a':
                    self.direction = 'd'
                    self.moved = False


        def main():
            root = tkinter.Tk()
            Application(root)
            root.mainloop()


        if __name__ == '__main__':
            main()
         
    
    elif btn == "Find Players Real Name":
        app.infoBox("b1","Please type user's username")       
        findname = app.stringBox("Find players real name","Enter the Username")
#reads the csv file and assigns it to the dataframe named namesfr    
        namesfr = pandas.read_csv("gamedata.csv")
#finds the username based on the user entered first name
        answername = namesfr[namesfr.Username==findname].Name
#conversion of the search result to a list
        answernamel = answername.tolist()
#displays to search result in a popup
        app.infoBox("Your Name is",answernamel)
#the following code mimics the one in the previous elif to    
    
    elif btn == "Find Date Enter":
        app.infoBox("b1","Please type user's username")
        findname = app.stringBox("Find users the Date when they play","Enter the Username")
#reads the csv file and assigns it to the dataframe named namesfr    
        namesfr = pandas.read_csv("gamedata.csv")
#finds the username based on the user entered first name
        answerdate = namesfr[namesfr.Username==findname].DateEnter
#conversion of the search result to a list
        answerdatel = answerdate.tolist()
#displays to search result in a popup
        app.infoBox("Your DateEnter is",answerdatel) 
        
    elif btn == "Find Players' Gender":
        app.infoBox("b1","Please type user's username")
        findname = app.stringBox("Find players Gender","Enter the Username")
#reads the csv file and assigns it to the dataframe named namesfr    
        namesfr = pandas.read_csv("gamedata.csv")
#finds the username based on the user entered first name
        answerg = namesfr[namesfr.Username==findname].Gender
#conversion of the search result to a list
        answergl = answerg.tolist()
#displays to search result in a popup
        app.infoBox("Your Gender is",answergl)     
       
            
    else:
            print('Pick a valid option')





"""
This section creates the Main Window, starting with a
Splash Screen then displaying the main window with
a graphic and buttons for each action.  When a button
is pressed, the press function (above) is called
""" 
app = gui("Main Menu","500x500")
#shows a splashpage for a few seconds
app.showSplash("Welcome!!!", fill='green', stripe='black', fg='white', font=44)
app.addLabel("title", "Welcome to the Game Center")
app.setLabelBg("title", "orange")

app.addImage("decor","snake.gif")


app.setFont(18)
#these are the buttons that call the press function
#note how the button names match each elif statement above
app.addButton("Dice Rolling Game", press)
app.addButton("Snake Game",press)
app.addButton("Find Players Real Name", press)
app.addButton("Find Date Enter", press)
app.addButton("Find Players' Gender", press)
app.addButton("Exit", press)
app.go()

